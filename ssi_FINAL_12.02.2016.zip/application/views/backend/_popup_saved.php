<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
	<div class="popup popup--save show">
		<div class="popup__box">
			<div class="popup__body"><?php echo lang('saved');?></div>
			<a class="icon-cancel-outline popup__close"></a>
		</div>
	</div>