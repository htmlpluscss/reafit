<?php
/* https://github.com/chernavin/CodeIgniter-Russian-Language */

$lang['terabyte_abbr']	= 'Тб';
$lang['gigabyte_abbr']	= 'Гб';
$lang['megabyte_abbr']	= 'Мб';
$lang['kilobyte_abbr']	= 'Кб';
$lang['bytes'] 			= 'Байт';

/* End of file number_lang.php */
/* Location: ./system/language/russian/number_lang.php */
